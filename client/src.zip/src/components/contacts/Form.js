import React from 'react'

export default class Form extends React.Component{
    constructor(props){
        super(props)
        this.state={
            name:props.contact ? props.contact.name:'',
            email:props.contact ? props.contact.email:'',
            mobile:props.contact ? props.contact.mobile:'',
            category:props.contact ? props.contact.category:''
        }
    }

    handleChange=(e)=>{
        this.setState({[e.target.name]:e.target.value})
    }

    handleSubmit=(e)=>{
        e.preventDefault()
        const formData={
            name:this.state.name,
            email:this.state.email,
            mobile:this.state.mobile,
            category:this.state.category,
        }
        // console.log(formData)
        this.props.handleSubmit(formData)
    }

    render(){
        return (
            <div>
                <h2>Add Contacts</h2>
                <form onSubmit={this.handleSubmit}>
                <label>name:
                    <input type='text' value={this.state.name} onChange={this.handleChange} name='name'/>
                </label><br/><br/>
                <label>email:
                    <input type='text' value={this.state.email} onChange={this.handleChange} name='email'/>
                </label><br/><br/>
                <label>mobile:
                    <input type='text' value={this.state.mobile} onChange={this.handleChange} name='mobile'/>
                </label><br/><br/>
                <label>category:
                    <input type='radio' value='home' name='category' onChange={this.handleChange}/>home
                    <input type='radio' value='work' name='category' onChange={this.handleChange}/>work
                </label><br/><br/>
                <input type='submit'/>
                </form>
            </div>
        )
    }
}