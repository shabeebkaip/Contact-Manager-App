import React from 'react'
import axios from '../../config/axios'
import {Link } from 'react-router-dom'
import {connect} from 'react-redux'
import { startGettingAllContacts} from '../../actions/contacts'

 class ContactList extends React.Component{
    constructor(props){
        super(props)
        this.state={
            contacts:[],
            copy:[],
            text:''
        }
    }

    componentDidMount(){
        // axios.get('/contacts',{
        //     headers:{
        //         'x-auth':localStorage.getItem('authToken')
        //     }
        // })
        // .then(response=>{
        //     const contacts=response.data
        //     this.setState({contacts,copy:contacts})
        // })
        this.props.dispatch(startGettingAllContacts())

    }
    handleChange=(e)=>{
        const text=e.target.value
        this.setState({text})
    }

    handleSearch=()=>{
        this.state.contacts=this.state.copy
    const contacts=this.state.contacts.filter(conc=>conc.name==this.state.text)
    this.setState({contacts})
    }

    render(){
        console.log('props', this.props.contacts)
        return(
            <div>
                <h2>Listing Contact-{this.props.contacts.length}</h2>
                <input type='text' value={this.state.text} onChange={this.handleChange}/><button onClick={this.handleSearch}>Search</button>
                <ul>
                    {
                        this.props.contacts.map(contact=>{
                            return <li key={contact._id}>{contact.name}<button><Link to={`/contacts/${contact._id}`}>Show</Link></button></li>
                        })
                    }
                </ul>

                <button><Link to='/contacts/add'>Add Contact</Link></button>
                
            </div>
        )
    }
}
const mapStateToProps = (state)=>{
    return {
        contacts: state.contacts
    }
}
export default connect(mapStateToProps)(ContactList)
