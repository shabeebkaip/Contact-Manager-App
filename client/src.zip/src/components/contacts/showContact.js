import React from 'react'
import axios from '../../config/axios'
import {Link } from 'react-router-dom'

class ShowContact extends React.Component{
    constructor(){
        super()
        this.state={
            contact:{}
        }
    }

    componentDidMount=()=>{
        const id=this.props.match.params.id
        axios.get(`/contacts/${id}`,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            // console.log(response.data)
            const contact=response.data
            this.setState({contact})
        })
        .catch(err=>{
            alert(err)
        })
    }

    handleRemove=()=>{
        const remove=window.confirm('are you sure?')
            if(remove){
        const id=this.props.match.params.id
        axios.delete(`/contacts/${id}`,{
            headers:{
                'x-auth':localStorage.getItem('authToken')
            }
        })
        .then(response=>{
            
            this.props.history.push('/contacts')
            
        })
        .catch(err=>{
            alert(err)
        })
    }
    }

    backHandle=()=>{
        this.props.history.push('/contacts')
    }
    render(){
        return (
            <div>
                <h2>Show Contact Info</h2>
                <p>{this.state.contact.name}-{this.state.contact.mobile}:{this.state.contact.category}</p>
                <br/>
                <button><Link to={`/contacts/edit/${this.props.match.params.id}`}>Edit</Link></button>
                <button onClick={this.handleRemove}>remove</button>
                <button onClick={this.backHandle}>back</button>
            </div>
        )
    }
}

export default ShowContact