const contactInitialState = {}

const contactReducer = (state=contactInitialState,action)=>{
    switch(action.type) {
        default :{
            return state
        }
    }
}